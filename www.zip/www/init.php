<?php
$ROOT_PATH = "/var/www/motifnet";
$ROOT_WEB_PATH = "/motifnet";
?>
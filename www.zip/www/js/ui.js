//**************************************************************************************//
//																						//
// This page holds scripts that are responsible for the UI and the presentation of data	//
//																						//
//**************************************************************************************//


function initUI(){
	
	//navigation handlers
	$('#nav-handle').mouseenter(function()
		{
			$('#nav-handle').hide('fast');
			$('#nav-body').show('fast');
			return false;
		}
	);
	
	$('#nav-body').mouseleave(function()
		{
			$('#nav-handle').show('fast');
			$('#nav-body').hide('fast');
			return false;
		}
	);	
	
	injectButtons();
	
	//make jquery buttonset
	$( "#nodes_hide_radio" ).buttonset();
	$( "#nodes_show_radio" ).buttonset();
	
	//make go button
	$("button").button();
	//$( "#go_button" ).click();


	//controlls
	$( "#accordion" ).accordion({ header: "h3" });
	
	//Get all nodes of the "show" group and set then to "on"
	var nodesShow = $("#nodes_show_checkboxes" ).children("input");
	nodesShow.each(function(index){ this.checked = true;	});
	nodesShow.button("refresh");
	
	//Get all nodes of the "show" group and set then to "on"
	var nodesShow = $("#edges_show_checkboxes").children("input");
	nodesShow.each(function(index){ this.checked = true;	});
	nodesShow.button("refresh");
	
	//Set all nodes of "hide" to off
	var nodesShow = $("#nodes_hide_checkboxes").children("input");
	nodesShow.each(function(index){ this.checked = false;	});
	nodesShow.button("refresh");
	
	//Set all nodes of "hide" to off
	var nodesShow = $("#edges_hide_checkboxes").children("input");
	nodesShow.each(function(index){ this.checked = false;	});
	nodesShow.button("refresh");
	
	//clear text areas & bind events
	$("textarea").each(function(){
        this.value="";
        this.onchange = textAreaChange;
        });
	
	
	//plugin of checkboxex pretty colors
	makeCheckboxes();
	
	
	//bind onChange events
	$("input:radio").each(function(){
        this.onclick = radioButtonChange;
        });
	
	$("input:checkbox").each(function(){
        this.onchange = checkBoxCahnge;
        });
	
	
	//TABS:
	// Tabs
	$('#tabs').tabs();
	
}

function injectButtons(){
	var div="";
	//1)
	//Inject show motifs with numbers:	
	for (var i=0;i<=6;i++){
		div+=createSingleButton(i,"show_node");
	}
	$("#nodes_show_checkboxes").html(div);
	$( "#nodes_show_checkboxes" ).buttonset();
	
	//2)
	//Inject hide motifs with numbers:
	div="";
	for (var i=0;i<=6;i++){
		div+=createSingleButton(i,"hide_node");
	}
	$("#nodes_hide_checkboxes").html(div);
	$("#nodes_hide_checkboxes").buttonset();
	
	//3)
	//Inject show motifs with edge color:
	div="";
	for (var i=0;i<=7;i++){
		div+=createSingleButton(i,"show_edge",indexToColor(i));
	}
	$("#edges_show_checkboxes").html(div);
	
	//4)
	//Inject hide motifs with edge color:
	div="";
	for (var i=0;i<=7;i++){
		div+=createSingleButton(i,"hide_edge",indexToColor(i));		
	}
	$("#edges_hide_checkboxes").html(div);
}

function createSingleButton(index, name,color){
	if (color==null)
		return "<input type='checkbox' id='"+name+"_"+index+"' /><label for='"+name+"_"+index+"'>"+index+"</label>";
	else
		return "<input type='checkbox' class='styled "+color+"' id='"+name+"_"+index+"' />";
}

function makeCheckboxes(){

    $('input[type=checkbox]').each(function() {
        var span = $('<span class="' + $(this).attr('type') + ' ' + $(this).attr('class') + '"></span>').click(doCheck).mousedown(doDown).mouseup(doUp);
        if ($(this).is(':checked')) {
            span.addClass('checked');
        }
        $(this).wrap(span).hide();
    });

    function doCheck() {
        if ($(this).hasClass('checked')) {        	
            $(this).removeClass('checked');
            $(this).children().prop("checked", false);
        } else {
            $(this).addClass('checked');
            $(this).children().prop("checked", true);
        }
        
        checkBoxCahnge({target:this.firstElementChild});
    }

    function doDown() {
        $(this).addClass('clicked');
    }

    function doUp() {
        $(this).removeClass('clicked');
    }
};


function indexToColor(index){
	var ans = "white"
	switch (index){
	case 0:
		ans="black"; //black
		break;
	case 1:
		ans="red"; //red
		break;
	case 2:
		ans="green"; //green
		break;
	case 3:
		ans="yellow"; //yellow
		break;
	case 4:
		ans="blue"; //blue
		break;
	case 5:
		ans="cyan"; //cyan
		break;
	case 6:
		ans="grey"; //grey
		break;
	case 7:
		ans="maroon"; //maroon
		break;
	}
	
	return ans;
}

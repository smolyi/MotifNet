
//dojo.require("dojo.debug.console");

// load up the required dojo json-rpc stuff
//dojo.require("dojo.event.*");
//dojo.require("dojo.io.*");

//dojo.require("dojo.rpc.*");

// spec up the remote json-rpc service
hostDef = {
      "serviceType": "JSON-RPC", 
      "serviceURL": "/motifnet-cgi/RPC-Client/CGIHandler.py",
      "sync": true,
      "methods":[ ]
    };

// create json-rpc service
host = new dojo.rpc.JsonService({smdObj:hostDef});

webServiceHandler = new Object();
webServiceHandler.lastCallTime= new Date().getTime(); //not null


function call(methodName, params, onGood, onBad){
	/*
	 * methodName - string. name of the method you want to call in the remote object on the server
	 * params - list. parameters of the requested method.
	 * onGood - callback function to execute upon success
	 * onBad - callback function to execute upon error
	 */
	//alert(" method. calling " + methodName +" with ["+params+"]");
	//$("#loadingMessage").html("Processing");
	//webServiceHandler.lastCallTime = new Date().getTime();
	//$("#loadingScreen").show();
	$("body").css("cursor", "wait");
	try
	{
		var onGoodWraped = function(result) { 
			$("body").css("cursor", "auto");
			onGood(result);
			};
		var onBadWraped = function(result) { 
			$("body").css("cursor", "auto");
			onBad(result);
			};
		var myDeferred = host.callRemote(methodName, params);
		myDeferred.addCallback(onGoodWraped);
		myDeferred.addErrback(onBadWraped);
	}
	catch(err)
	{
		$("body").css("cursor", "auto");
		alert("catch! "+err);
		
	}
}


// COMMANDS
function querySessions(){
	call("GetSessions", [USER], handleSessionsResponse,alertException );
}
function login(){
	USER = $("input#user").val();
	call("GetUser", [USER], handleSessionResponse, alertException);
	
}
function logout(){
	USER = null;
	init();
	
}
function register(){
	call("CreateUser", [$("input#registeredUser").val(),$("input#registeredEmail").val(),$("input#registeredInstitution").val()], handleRegisterResponse, alertException);
}


//CALLBACKS
function handleSessionResponse(result){
	
	var resObj = result;
	
	if (resObj.length==0){
		alert("no user found with name "+USER);
		return;
	}
	var html = "<h2>Welcome "+ resObj[1] + "! </h2><br>"
	html += "what would you like to do? <br>"
	$("#startPanelHeader").html(html)
	$("#startPanel").css("display","block")
	$("#loginPanel").css("display","none")
}

function handleSessionsResponse(res){
	//alert("sss");
	var sessions = res;
	if (sessions.length==0){
		$("div#sessions").empty();
		alert("no sessions found for user - "+USER+"");
		return;
	}
	var html = "<h4>Sessions:</h4>"
	html += "<form id='sessionsForm' action='search.php' method='post'> <input id='jobid' name='jobid' type=hidden value='-1' />"
	html += "<table id='sessionsTable' ><tr><td>id</td><td>name</td><td>time</td><td>comments</td><td>delete</td></tr>"
	
	for (i=0;i<sessions.length;i++){
		var inst = sessions[i];
	    html += "<tr>";
	    html += "<td>"+inst['id']+"</td>";
	    html += "<td><a href='javascript:gotoSearchPage("+inst['id']+");' >"+inst['name']+"</td>";
	    html += "<td>"+inst['time']+"</td>";
	    html += "<td>"+inst['comments']+"</td>";
	    html += "<td><a onclick=\"deleteJob('"+inst['id']+"')\" href='' >delete</a></td>";
	    html += "</tr>";
	
	}
	html += "</table></form>"
	$("div#sessions").html(html);
	$("#startResults").css("display","block")
}
function handleRegisterResponse(res){
	response = res;
	if (response.length<4){
		alert(response[0]);
	}
	else{
		$("input#user").val(response[1]);
		login();
	}
}

function alertException(){
	alert("RPC_ERROR: "+err.message);
}
















//OLD example

webServiceHandler.getNodeByName = function(nodeName, nodeType){
	call("GetNodeByName", [Session.GUID,nodeName,nodeType,Session.email], onNodeDone, onCalculateError);
	
};

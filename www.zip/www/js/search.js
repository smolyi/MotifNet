var motifImagesDirectoryPath = "/motifnet/Sessions/Motifs/"
var xmlhttp=false;
var countCalls = 0 ;
var sortNodes = 0;
var sortEdges = 0;
var JOBID = -1
$.ajaxSetup ({  
    cache: false  
}); 


if (!xmlhttp && typeof XMLHttpRequest!='undefined') {

	try {
      xmlhttp = new XMLHttpRequest();
    } catch (e) {
      xmlhttp = false;
    }

}

function init(job){
	$(document).ready(function(){
		//alert(job);
		JOBID = job;
		initUI();
		callScript(remoteObj.printData,cb_sessionData);
		submitQuery();
	})
}

function printEdgeData(jobid, int1, int2){
	alert("printEdgeData() not implemented yet !!!");
}
function queryMotif(adj, sortnodes, sortedges){
	sortNodes = sortnodes;
	sortEdges = sortedges;
	call("GetMotif",[JOBID,adj],openInstances,alertException);
}
function submitQuery(){
	formObj = getFormObject(formObj);
    	formObj['jobid'] = JOBID;
    	var params = [formObj.jobid, 
    	[formObj.proteins,formObj.radioProteinShow], 
    	[], 
    	[formObj.showedges,formObj.radioEdgeShow], 
    	formObj.hideedges, 
    	[formObj.shownodes,formObj.radioNodeShow], 
    	formObj.hidenodes, 
    	formObj.minInstances, 
    	formObj.maxPvalue, 
    	formObj.minZscore, 
    	formObj.minFrequency]
    	
	call("GetMotifs",params,cb_motifs,alertException);

}
function resetForm(){
	alert("resetForm() is not implemented yet!");
}



// CALLBACKS
function cb_sessionData( res ) {
	$("#session-data").html(res);
}

function cb_motifs( res ) {
	var motifList = res;  //JSON.parse(res); //if json server is not running
	var ul = $("#resultsList");
	ul.empty();
	var count = 0;
	for (key in motifList){
		count ++;
		var motif = motifList[key];
		//alert(motif['img_path']);

		var imagePath = motifImagesDirectoryPath + JOBID + "/" + motif['img_path'];
		var html = "<li id="+motif['adj']+"><table class='motifTable'><tr><th>Adj</th><th>Inst</th><th>P</th><th>Z</th><th>Freq</th></tr>";
		html += "<tr><td>"+motif['adj']+"</td><td>"+motif['count']+"</td><td>"+motif['pval']+"</td><td>"+motif['zscore']+"</td><td>"+motif['freq']+"</td></tr><tr><td colspan='5'><div class='crop'>";
		html +="<img class='motifImage' src='"+imagePath+"' alt='"+imagePath+"' ></div></td></tr></table></li>";
		ul.append(html);
		
	}
	alert("Query executed. "+count+" motifs found.");
	
	$("#resultsList li").click(function() {
		queryMotif(this.id);
	 });
		
    
}

function cb_instance( res ) {
	//Put the result here, it need to be parsed
	$("#hidden-helper").html(res);
	
	//Put each div in its appropriate tab
	$("#tabs-0").html($("#hidden-helper #motif_summary").html());
	$("#tabs-1").html($("#hidden-helper #instances_subgraphs").html());
	$("#tabs-2").html($("#hidden-helper #instances_nodes").html());
	$("#tabs-3").html($("#hidden-helper #instances_edges").html());
	
	$('#tabs').tabs();
	
}


function openInstances(motif){
	/*
	 * display data about the instances of the motif corresponds to 'adj' in the instances tabs.
	 * 
	 * prepare an html code and send it to  cb_instance() for parsing
	 * (this is a little bit wierd but implemented this way from system evolutionary reasons.
	 *
	 */
	var MAX_ENTRIES = 1000; //Maximum entries in the tables displayed

	var size = parseInt(motif['size']);
	var html = "";
	
	//alert(motif['instances'].length);
	if (sortNodes==undefined  || sortNodes < 0)
		sortNodes = size+1;
	if (sortEdges==undefined || sortEdges < 0)
		sortEdges = factorial(size)+1;

	//motif summary
	var imagePath = motifImagesDirectoryPath + JOBID + "/" +motif['img_path'];
	html += "<div id='motif_summary'><table  class='instances_display_table' >";
	html += "<tr><td>adj</td><td>"+motif['adj']+"</td></tr>";
   	html += "<tr><td>size</td><td>"+motif['size']+"</td></tr>";
   	html += "<tr><td>subgraphs</td><td>"+motif['instances'].length+"</td></tr>";
   	html += "<tr><td>pvalue</td><td>"+motif['pval']+"</td></tr>";
   	html += "<tr><td>zscore</td><td>"+motif['zscore']+"</td></tr>";
   	html += "<tr><td>frequency</td><td>"+motif['freq']+"</td></tr>";
   	html +="</table><img class='motifImage' src='"+imagePath+"' alt='"+imagePath+"' ></div>";
    
    
    	//alert("subgraphs");
	//subgraphs
	html += "<div id='instances_subgraphs'><table class='instances_display_table' >";

	html += "<tr><td>id</td>";
	for (i=1; i < size+1; i++) 
		html += "<td>node"+i+"</td>";
	for (i=1; i < factorial(size)+1; i++)
	    html += "<td>edge"+i+"</td>";
	html += "</tr>";
	count = 0;
	for (k=0; k < Math.min(motif['instances'].length,MAX_ENTRIES); k++){
		inst = motif['instances'][k];
	    count += 1;
	    html += "<tr><td>"+count+"</td>";
	    for (i=0; i < size; i++) 
		html += "<td>"+inst[i]+"</td>";
	    for (i=0; i < size; i++) {
		for (j=0; j < size; j++) {
		    if (i!=j)
		        html += "<td><a href=javascript:printEdgeData(\'"+JOBID+"\',\'"+inst[i]+"\',\'"+inst[j]+"\'); >"+inst[i]+"-"+inst[j]+"</a></td>";
		}
	    }
	    html += "</tr>";
	}

	html += "</table></div>"


	//alert("nodes");
	//nodes
	html += "<div id='instances_nodes'>";
	var nodesList = getNodesFrequencyTable(motif['instances'], size, sortNodes);

	html += "<table class='instances_display_table' ><tr><td>num</td>";
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',0,"+sortEdges+");\" style=\"cursor:pointer;\">gene</div></td>";
	for (i=1; i < size+1; i++) 
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',"+(i)+","+sortEdges+");\" style=\"cursor:pointer;\">pos"+i+"</div></td>";
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',"+(i)+","+sortEdges+");\" style=\"cursor:pointer;\" >total</div></td>";
	html += "</tr>";
	count = 0 ;

	for (k=0; k < Math.min(nodesList.length,MAX_ENTRIES); k++){
	var gene = nodesList[k][0];
	var freqList = nodesList[k].slice(1);
	count += 1;
	html += "<tr><td>"+count+"</td><td>"+gene+"</td>";
	for (i=0; i < freqList.length; i++)  
	    html += "<td>"+freqList[i].toFixed(3)+"</td>";
	html += "</tr>";
	}
	html += "</table></div>";


	//alert("edges");
	//edges
	html += "<div id='instances_edges'>";
	var edgeList = getEdgesFrequencyTable(motif['instances'], motif['adj'], size, sortEdges);
	html += "<table class='instances_display_table' ><tr><td>num</td>";
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',"+sortNodes+",0);\" style=\"cursor:pointer;\">edge</div></td>";
	for (i=1; i < factorial(size)+1; i++) 
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',"+sortNodes+","+i+");\" style=\"cursor:pointer;\">pos"+i+"</div></td>";
	html += "<td><div onclick=\"queryMotif(\'"+motif['adj']+"\',"+sortNodes+","+i+");\" style=\"cursor:pointer;\">total</div></td>";
	html += "</tr>";
	count = 0 ;
	for (k=0; k < Math.min(edgeList.length,MAX_ENTRIES) ; k++){
	var edge = edgeList[k][0];
	var freqList = edgeList[k].slice(1);
	count += 1;
	html += "<tr><td>"+count+"</td><td>"+edge+"</td>";
	for (i=0; i < freqList.length ; i++)  
	    html += "<td>"+freqList[i].toFixed(3)+"</td>";
	html += "</tr>";
	}
	html += "</table></div>";
   	
   	if (edgeList.length >= MAX_ENTRIES || nodesList.length  >= MAX_ENTRIES || motif['instances'].length >= MAX_ENTRIES)
  		alert("You requested data of motif with too many occurences. Please, note that only "+ MAX_ENTRIES + " entries are shown in each table.");
  		
	cb_instance(html);
	
}
function getNodesFrequencyTable(instances,size, sortIndex){
	var instanceDict = new Array();
	
    for (k=0; k < instances.length; k++){
		ins = instances[k];
        for (i=0; i < size; i++) {
        	var geneName = ins[i];
            if (!(geneName in instanceDict)){ 
            	instanceDict[geneName] = [];
            	for (l=0; l < size + 1; l++)
            		instanceDict[geneName].push(0);
            }
            instanceDict[geneName][i] += 1;
            instanceDict[geneName][size] += 1;
        }
    }    
    for (gene in instanceDict){
    	ins = instanceDict[gene];
        for (i=0; i < ins.length; i++)
        	ins[i] = (ins[i])/instances.length ;
    }
	var arr = [];
    for (key in instanceDict){
    	arr.push([key].concat(instanceDict[key]));
    }
    
    if (sortIndex == 0)
    	arr.sort(function(a,b){ if (a[sortIndex] < b[sortIndex]) return -1;      if (a[sortIndex] > b[sortIndex]) return 1;       return 0; });
    else
    	arr.sort(function(a,b){ return b[sortIndex]-a[sortIndex] });
    return arr;
}
function getEdgesFrequencyTable(instances, adj,size, sortIndex){
	var instanceDict = new Array();
	
    for (k=0; k < instances.length; k++){
		ins = instances[k];
		var pos = 0;
        for (i=0; i < size; i++) {
        	for (j=0; j < size; j++) {
        		if (i!=j){
        			var edge = ins[i]+","+ins[j];
	        		if (parseInt(adj[i*size+j])>0){
			            if (!(edge in instanceDict)){ 
			            	instanceDict[edge] = [];
			            	for (l=0; l < factorial(size) + 1; l++)
			            		instanceDict[edge].push(0);
			            }
			            instanceDict[edge][pos] += 1;
			            instanceDict[edge][instanceDict[edge].length-1] += 1;
	        		}
		            pos ++;
        		}
        	}
        }
    }    
    for (edge in instanceDict){
    	ins = instanceDict[edge];
        for (i=0; i < ins.length; i++)
        	ins[i] = (ins[i])/instances.length ;
    }
    var arr = [];
    for (key in instanceDict){
    	arr.push([key].concat(instanceDict[key]));
    }
    if (sortIndex == 0)
    	arr.sort(function(a,b){ if (a[sortIndex] < b[sortIndex]) return -1;      if (a[sortIndex] > b[sortIndex]) return 1;       return 0; });
    else
    	arr.sort(function(a,b){ return b[sortIndex]-a[sortIndex] });
    return arr;
}
function factorial(n) {
  if ((n == 0) || (n == 1))
    return 1
   else {
      result = (n * factorial(n-1) )
      return result
   }
}
/* -------------- NOT  YET GOT FOR --------------*/



function queryAdj(){
		getData('/cgi-bin/MotifNetServer/Query/queryInstances.py', 'instances',true);
		getData('/cgi-bin/MotifNetServer/Query/printData.py', 'left_bottom_display_div', true);
	}
	
function deleteJob(jobName){
var ans = confirm("are you sure you want to delete the job '"+jobName+"' permanently???");
if(xmlhttp && ans==true){
		
		url = "/cgi-bin/MotifNetServer/Admin/deleteSession.py";
		paramStr = "job="+jobName;
	    // set the necessary request headers
	    xmlhttp.open("post", url,false);	
	    /*
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 &&	xmlhttp.status == 200) {
				obj.innerHTML = xmlhttp.responseText;
			}
		}
		*/
			
	    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	    xmlhttp.setRequestHeader("Content-length",paramStr.length);
	    xmlhttp.setRequestHeader("Connection", "close");
		xmlhttp.send(paramStr);	
		
	}
}


function queryJob(jobId){
form = document.getElementById("query");
document.getElementById("job").value = jobId;
form.submit();
}



function callScript(scriptUrl, callBackFunc){
	
	//wait counter
	countCalls++;
		
	//set mouse cursor to wait     
    $("body").css("cursor", "wait");
    
    //Get Params for query
    formObj = getFormObject(formObj);
    formObj['jobid'] = JOBID;
	var param =  { jsonQueryString: JSON.stringify(formObj)};
	
	var onGoodWraped = function(result) { 
			$("body").css("cursor", "auto");
			callBackFunc(result);
			};    

    
    //call
	$.ajax({
		type: "POST",
		url: scriptUrl,
		data:param,
		success:onGoodWraped
		});
}


/* ------------ Data object -------------*/

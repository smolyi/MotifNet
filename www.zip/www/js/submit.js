var cgi_bin_rootPath = "/motifnet-cgi/ExecutionScripts"
var submissionObject = null;
var filesData = {};
var numberOfNodeFiles = 8;
var numberOfEdgeFiles = 8;

function addUserInput(form){
	var input = document.createElement('input');
	input.type = 'hidden';
	input.name = 'user';
	input.value = USER;
	form.appendChild(input);
}
function submitJob(){
	var form = document.getElementById("submitJobForm");
	form.action = cgi_bin_rootPath+"/Submit/submitJob.py";
	addUserInput(form);

	
	form.submit();
	/*
	finalizeSubmitObject();
	
	var scriptUrl = cgi_bin_rootPath+"/Submit/submitJob.py";	
	callScript(scriptUrl);
	*/
}

function generateGraph(){
	var form = document.getElementById("submitJobForm");
	form.action = cgi_bin_rootPath+"/Submit/generateFanmodInput.py";
	
	form.submit();
	/*
	finalizeSubmitObject();
	var scriptUrl = cgi_bin_rootPath+"/Submit/generateFanmodInput.py";	
	callScript(scriptUrl);
	*/
}

	
function submitFandmodOutput(){
	var form = document.getElementById("outputSubmissionForm");
	form.action = cgi_bin_rootPath+"/Submit/submitFanmodOutput.py";
	addUserInput(form);

	form.submit();
	
	/*
	finalizeSubmitOutputObject();
	var scriptUrl = cgi_bin_rootPath+"/Submit/submitFanmodOutput.py";	
	//call("SubmitFanmodOutput", ["params"],success,fail);
	
	callScript(scriptUrl);
	*/
}


function filesAreReady(){
	//return !(data==null)
	for (key in filesData){
		if (!filesData[key][1]){
			//alert(key+" "+ filesData[key]);
			return false;}
	}
	return true;
}

function readFile(key, file){
	if (file!=null ){
		filesData[key] = [];
		filesData[key][0]=null;
		filesData[key][1]=false;
		var reader = new FileReader();
		
		reader.onload = function(e) {
		
	        filesData[key][0]=e.target.result;
	        filesData[key][1]=true;
	        };
	    
		
		reader.readAsText(file);
	}
}

function finalizeSubmitObject(){
	obj = {
		jobName: "-",
		email: "-",
		sizeOfMotif: 3,
		nodeFiles:[],
		edgeFiles:[],
		minInstances : 1,
		maxPvalue : 1, 
		minZscore : 0,
		minFrequency : 0,
		onlyColoured : false,
		dangledEdges : 2
	};
	obj.jobName = $("#submitJobForm input[name=job]").val();
	obj.email = $("#submitJobForm input[name=email]").val();
	obj.sizeOfMotif = parseInt($("#submitJobForm select[name=sizeOfMotif]").val());
	for (i=1;i<=8;i++)
		obj.nodeFiles.push([$("#submitJobForm input[name=nodeFile"+i+"]").val(),$("#submitJobForm input[name=nodeFile"+i+"_label]").val()]) ;
	for (i=1;i<=8;i++)
		obj.edgeFiles.push([$("#submitJobForm input[name=edgeFile"+i+"]").val(),"on"==$("#submitJobForm input[name=edgeFile"+i+"_directed]:checked").val()]) ;
	
	obj.maxPvalue  = parseFloat($("#submitJobForm input[name=maxPvalue]").val());
	obj.minInstances  = parseInt($("#submitJobForm input[name=minOccurrences]").val());
	obj.minZscore  = parseFloat($("#submitJobForm input[name=minZscore]").val());
	obj.dangledEdges  = parseInt($("#submitJobForm input[name=maxDangling]").val());
	obj.onlyColoured  = "on"==$("#submitJobForm input[name=onlyColored]:checked").val();
	//minFrequency  = $("input[name=freq]").val();

	submissionObject = obj;
}
function finalizeSubmitOutputObject(){
	obj = {
		jobName: "-",
		email: "-",
		comments: "-",
		csvFile:null,
		dumpFile:null,
		nodesMappingFile : null,
		labelsMappingFile : null, 
		networkFile: null,
		minInstances : 1,
		maxPvalue : 1, 
		minZscore : 0,
		minFrequency : 0,
		onlyColoured : false,
		dangledEdges : 2
	};
	obj.jobName = $("#outputSubmissionForm input[name=jobName]").val();
	obj.email = $("#outputSubmissionForm input[name=email]").val();
	obj.comments = $("#outputSubmissionForm textarea[name=comments]").val();
	
	/*
	obj.csvFile = $("#outputSubmissionForm input[name=csvFile]").val();
	obj.dumpFile = $("#outputSubmissionForm input[name=dumpFile]").val();
	obj.nodesMappingFile = $("#outputSubmissionForm input[name=nodesMappingFile]").val();
	obj.labelsMappingFile = parseInt($("#outputSubmissionForm select[name=labelsMappingFile]").val());
	obj.networkFile = $("#outputSubmissionForm input[name=networkFile]").val();
	*/
	
	obj.maxPvalue  = parseFloat($("#outputSubmissionForm input[name=maxPvalue]").val());
	obj.minInstances  = parseInt($("#outputSubmissionForm input[name=minOccurrences]").val());
	obj.minZscore  = parseFloat($("#outputSubmissionForm input[name=minZscore]").val());
	obj.dangledEdges  = parseInt($("#outputSubmissionForm input[name=maxDangling]").val());
	obj.onlyColoured  = "on"==$("#outputSubmissionForm input[name=onlyColored]:checked").val();
	//minFrequency  = $("input[name=freq]").val();
	/*
	readFile("csvFile",document.getElementById("csvFile").files[0]);
	readFile("dumpFile",document.getElementById("dumpFile").files[0]);
	readFile("nodesMappingFile",document.getElementById("nodesMappingFile").files[0]);
	readFile("labelsMappingFile",document.getElementById("labelsMappingFile").files[0]);
	readFile("networkFile",document.getElementById("networkFile").files[0]);
	*/
	submissionObject = obj;
		
}
function addFilesToSubmissionObject(){
	for (key in filesData){
		submissionObject[key] = filesData[key];
	}
}
function callScript(scriptUrl){
	
	if(!filesAreReady()){
		setTimeout(callScript(scriptUrl),1000);
		return ;
	}
	
	addFilesToSubmissionObject();
	
	//set mouse cursor to wait     
    $("body").css("cursor", "wait");
    
    //Get Params for query
	//var param =  { jsonQueryString: JSON.stringify(submissionObject)};
	var param = new FormData();
	jQuery.each($('.file')[0].files, function(i, file) {
	    data.append('file-'+i, file);
	});
	
    //call
	$.ajax({
		type: "POST",
		url: scriptUrl,
		data:param,
		success:function(res){
			//"your request is in progress. you will be notified by email when process is done."
			alert("Response:\n"+res);
		},
		error:function (xhr, ajaxOptions, thrownError){
                    alert(xhr.status);
                    alert(ajaxOptions);
                    alert(thrownError);
                    
                }  
		});
	
	
	$("body").css("cursor", "auto");
	
}

function success(res){ alert(res); }
function fail(xhr, ajaxOptions, thrownError){
	alert(xhr.status);
	alert(ajaxOptions);
	alert(thrownError);}

function formMode(){
	var mode = $("input[name=mode]:checked").val();
	switch (mode){
		case "graph":
			$("#outputSubmissionForm").css("display","none");
			$("#submitJobForm").css("display","block");
			$(".submitOnly").css("display","none");
			$(".graphOnly").css("display","block");
			sizeChanged();
			break;
		case "submit":
			$("#outputSubmissionForm").css("display","none");
			$("#submitJobForm").css("display","block");
			$(".submitOnly").css("display","block");
			$(".graphOnly").css("display","none");
			sizeChanged();
			break;
		case "output":
			$("#outputSubmissionForm").css("display","block");
			$("#submitJobForm").css("display","none");
			break;
	}
}
function sizeChanged(){
	var size = parseInt(document.getElementById("sizeOfMotif").value);
	switch (size){
		case 3: 
			numberOfEdgeFiles = 7;
			numberOfNodeFiles = 16;
			break;
		case 4: 
			numberOfEdgeFiles = 7;
			numberOfNodeFiles = 16;
			break;
		case 5: 
			numberOfEdgeFiles = 3;
			numberOfNodeFiles = 8;
			break;
		case 6: 
			numberOfEdgeFiles = 3;
			numberOfNodeFiles = 1;
			break;	
		case 7: 
			numberOfEdgeFiles = 1;
			numberOfNodeFiles = 1;
			break;
		case 8: 
			numberOfEdgeFiles = 1;
			numberOfNodeFiles = 1;
			break;
	}
	writeFilesDivs();
}
function writeFilesDivs(){
	var nodeContent = "Nodes files: <br>";
	var edgeContent = "Edges files: <br>";
	
	for(i=1;i<=numberOfNodeFiles;i++){
		nodeContent += "Node file"+i+": ";
		nodeContent +=  "<input id='nodeFile"+i+"' name='nodeFile"+i+"' type='file' size=5 />\t";
		nodeContent +=  "Label = <input id='nodeFile"+i+"_label' name='nodeFile"+i+"_label' type='text' size=1 value='"+(i-1)+"' />";
		nodeContent +=  "<br>";
	}
	for(i=1;i<=numberOfEdgeFiles;i++){
		edgeContent += "Edge file"+i+": ";
		edgeContent +=  "<input id='edgeFile"+i+"' name='edgeFile"+i+"' type='file' size=5 />\t";
		edgeContent +=  "Directed = <input id='edgeFile"+i+"_directed' name='edgeFile"+i+"_directed' type='checkbox' checked />";
		edgeContent +=  "<br>";
	}
	$("#nodeFiles").html(nodeContent);
	$("#edgeFiles").html(edgeContent);
}

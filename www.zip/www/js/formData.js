var cgi_bin_rootPath = "/cgi-bin/MotifNetServer"

function getFormObject(obj){
	obj.radioProteinShow = $("input[name=radioProteinShow]:checked").val();
	obj.radioNodeShow = $("input[name=radioNodeShow]:checked").val();
	obj.radioEdgeShow = $("input[name=radioEdgeShow]:checked").val();
	obj.minInstances = $("input#inst").val();
	obj.maxPvalue = $("input#pval").val();
	obj.minZscore = $("input#zscore").val();
	
	var proteinsTesx = $("textarea#proteinText").val();
	obj.proteins = proteinsTesx.split("\n");
	return obj;
}
var formObj = {
		jobid : -1,
		proteins:[],
		radioProteinShow: 1,
		shownodes:[true,true,true,true,true,true,true],
		radioNodeShow:1,
		hidenodes:[false,false,false,false,false,false,false],
		showedges:[true,true,true,true,true,true,true],
		radioEdgeShow:1,
		hideedges:[false,false,false,false,false,false,false],
		minInstances : 1,
		maxPvalue : 1, 
		minZscore : 0,
		minFrequency : 0
	};


var remoteObj = {
		printData : '/cgi-bin/MotifNetServer/ExecutionScripts/Query/printSessionData2.py',
		queryMotif : '/cgi-bin/MotifNetServer/ExecutionScripts/Query/queryMotifs2.py',
		queryInstance : '/cgi-bin/MotifNetServer/ExecutionScripts/Query/queryInstances2.py',
		deleteSession : '/cgi-bin/MotifNetServer/ExecutionScripts/Admin/deleteSession.py'
};

function textAreaChange(event){
	var element = event.target;
	formObj[element.id] = element.value; 
}

function radioButtonChange(event){
	var element = event.target;
	formObj[element.name] = element.value; 
} 

function checkBoxCahnge(event){
	var element = event.target;
	var arr = element.id.split("_"); 	// arr [section,operation,value]
	formObj[arr[0]+arr[1]+"s"][Number(arr[2])] = element.checked; 
}

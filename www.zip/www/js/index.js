var querySessionsUrl = '/cgi-bin/MotifNetServer/Query/querySessions.py';
var queryUserUrl = '/cgi-bin/MotifNetServer/Query/queryUser.py';
var registerUserUrl = '/cgi-bin/MotifNetServer/Query/registerUser.py';
var submissionObject = null;
var USER = null;

function init(){
	$(document).ready(function() {
		$('#loginPanel').show();
		$('#startPanel').hide();
		$('#startResults').hide();
		});
}


// HTML functions
function loadSubmissionPage(){
	$("#mainContainer").load("submit.php");
}
function gotoSearchPage(jobid){
	var form = document.getElementById("sessionsForm");
	document.getElementById("jobid").value = jobid;
	form.submit();
}

function changeRegisterDiv(){
	var button = $("#registerButton");
	var registerDiv = $("#register");
	switch (button.html()){
		case "register":
			registerDiv.css("display","block");
			button.html("abort");
			break;
		case "abort":
			registerDiv.css("display","none");
			button.html("register");
			break;
	}
}



// NOT IN USE
function callScript(scriptUrl,responseFunction){
	//set mouse cursor to wait     
    $("body").css("cursor", "wait");
    
    //set Params for query
	var param =  { jsonQueryString: JSON.stringify(submissionObject)};
	
	var wrapedCCB = wrapCallback(responseFunction);
	
    //call
	$.ajax({
		type: "POST",
		url: scriptUrl,
		data:param,
		success:wrapedCCB,
		error:function (xhr, ajaxOptions, thrownError){
                    alert(xhr.status);
                    alert(thrownError);
                }  
		});
	
}
function wrapCallback(fun){
	return function(res){	
	    $("body").css("cursor", "auto");
	    //original code
	    return fun(res);
	};
}

// COMMANDS
function querySessions(){
	submissionObject = {user:USER};
	call("GetSessions", [USER], handleSessionsResponse,alertException );
	//callScript(querySessionsUrl, handleSessionsResponse)	;
}
function login(){
	USER = $("input#user").val();
	submissionObject = {user:USER};
	call("GetUser", [USER], handleSessionResponse, alertException);
	//callScript(queryUserUrl, handleSessionResponse)	;
	
}
function logout(){
	USER = null;
	init();
	
}
function register(){
	call("CreateUser", [$("input#registeredUser").val(),$("input#registeredEmail").val(),$("input#registeredInstitution").val()], handleRegisterResponse, alertException);
	/*
	submissionObject = {
		user:$("input#registeredUser").val(),
		email:$("input#registeredEmail").val(),
		institution:$("input#registeredInstitution").val()};
	call(registerUserUrl, handleRegisterResponse)	;
	*/
}

/*
//CALLBACKS
function handleSessionResponse(result){
	
	var resObj = result;
	
	if (resObj.length==0){
		alert("no user found with name "+USER);
		return;
	}
	var html = "<h2>Welcome "+ resObj[1] + "! </h2><br>"
	html += "what would you like to do? <br>"
	$("#startPanelHeader").html(html)
	$("#startPanel").css("display","block")
	$("#loginPanel").css("display","none")
}

function handleSessionsResponse(res){
	var sessions = res;//JSON.parse(res);
	if (sessions.length==0){
		$("div#sessions").empty();
		alert("no sessions found for user - "+USER+"");
		return;
	}
	var html = "<h4>Sessions:</h4>"
	html += "<form id='sessionsForm' action='search.php' method='post'> <input id='jobid' name='jobid' type=hidden value='-1' />"
	html += "<table id='sessionsTable' ><tr><td>id</td><td>name</td><td>time</td><td>comments</td><td>delete</td></tr>"
	
	for (i=0;i<sessions.length;i++){
		var inst = sessions[i];
	    html += "<tr>";
	    html += "<td>"+inst['id']+"</td>";
	    html += "<td><a href='javascript:gotoSearchPage("+inst['id']+");' >"+inst['name']+"</td>";
	    html += "<td>"+inst['time']+"</td>";
	    html += "<td>"+inst['comments']+"</td>";
	    html += "<td><a onclick=\"deleteJob('"+inst['id']+"')\" href='' >delete</a></td>";
	    html += "</tr>";
	
	}
	html += "</table></form>"
	$("div#sessions").html(html);
	$("#startResults").css("display","block")
}
function handleRegisterResponse(res){
	response = res;//JSON.parse(res);
	if (response.length<4){
		alert(response[0]);
	}
	else{
		$("input#user").val(response[1]);
		login();
	}
}

function alertException(){
	alert("RPC_ERROR: "+err.message);
}
*/

<?php 
require_once('init.php');
$JOBID = $_POST['jobid'];
?>
<html>
<head>
<title>motifNet</title>

<link rel="stylesheet" type="text/css" href="css/main.css" />
<link type="text/css" href="css/smoothness/jquery-ui-1.8.20.custom.css" rel="stylesheet" />

<script type="text/javascript" src="js/jQuery/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jQuery/jquery-ui-1.8.20.custom.min.js"></script>
<script type="text/javascript" src="js/cgiServiceInterface/dojo_rpc_only.js"></script>
<script type="text/javascript" src="js/cgiServiceInterface/webServiceInterface.js"></script>
<script type="text/javascript" src="js/formData.js"></script>
<script type="text/javascript" src="js/search.js"></script>
<script type="text/javascript" src="js/ui.js"></script>


		
</head>
<body  onload="init(<?php echo $JOBID; ?>);">	

	<div id="main-wrapper">
		
		<div id="navigation-wrapper">
			<div id="nav-handle">
				&laquo Job 
			</div>
			<div id="nav-body">
				<ul id="navigation-list">
					<!--<li><a href="<?php echo $ROOT_WEB_PATH; ?>/submit.php">Submit a job</a></li>-->
					<!--<li><a href="<?php echo $ROOT_WEB_PATH; ?>/submitFanmodOutput.php">Submit fanmod output</a></li>-->
					<li><a href="<?php echo $ROOT_WEB_PATH; ?>/index.html">Back to main page</a></li>
				</ul>	
			</div>
		</div>
	
		<div id="content-wrapper" class="content">
		
			<div id="left-wrapper">
				
				<h2 >Query form</h2>
				<div id="controls">
				</br>	
					<div id="accordion">
					    <h3><a href="#">Proteins</a></h3>
					    <div>
					    	<h4>Query motifs with</h4>
					    	<textarea id="proteinText"	rows="4" cols="18" 
					    				title="Line separated list of proteins"></textarea>
					    	</br>
					    	<input name="radioProteinShow" type="radio" value="1" /> All of the above proteins</br>
							<input name="radioProteinShow" type="radio" value="2" checked/> At least one protein</br>
							
							<!--	
					    	<h4>Protein World</h4>
					    	<textarea id="worldText"	rows="4" cols="18" 
					    				title="Line separated list of worlds"></textarea></br>				    	
							-->
					    </div>
					    <h3><a href="#">Nodes Numbers</a></h3>
					    <div >
					    	<h4>Show motifs with</h4>				    										
								<div id="nodes_show_checkboxes" >
									nodes numbers buttons will be injected here
								</div>					
								<input name="radioNodeShow" type="radio" value="1" /> All of the above nodes</br>
								<input name="radioNodeShow" type="radio" value="2" checked/> At least one node</br>
							</br>
							
					    	<h4>Hide motifs with </h4>				    	
					    	<div id="nodes_hide_checkboxes" >
									nodes numbers buttons will be injected here
					    	</div>
					    	
					    </div>
					    <h3><a href="#">Edge Color</a></h3>
					    <div >
					    	<h4>Show motifs with</h4>				    										
								<div id="edges_show_checkboxes" >
									edges colors buttons will be injected here
								</div></br></br>				
								<input name="radioEdgeShow" type="radio" value="1" /> All of the above colors</br>
								<input name="radioEdgeShow" type="radio" value="2" checked/> At least one color</br>
							</br>
							
					    	<h4>Hide motifs with </h4>				    	
					    	<div id="edges_hide_checkboxes" >
									edges colors buttons will be injected here
					    	</div></br></br>
					    	
					    </div>
					    
					    <h3><a href="#">Statistics</a></h3>
					    <div>						
							<div id="stats">
							<table class="gridtable">
							<tr><td>Max Pvalue: </td><td><input id="pval" name="pval" type="text" value=0.05 size=5 \></td></tr>
							<tr><td>Min instances: </td><td><input id="inst" name="inst" type="text" value=5 size=5 \></td></tr>
							<tr><td>Min Z-score: </td><td><input id="zscore" name="zscore" type="text" value=0 size=5 \></td></tr>
							</table>
							
							</div>
						</div>
					</div>
					</br>
					<div id='session-data'></div>
					</br>
					<div id="go">
						<button id="go_button" onclick="submitQuery();" ><p style="width: 36;"> GO! </p></button>
						<button id="form_reset" onclick="resetForm();" ><p style="width: 36;"> Reset </p></button>
					</div>
					
				</div>
				<div id="session-info"></div>
			</div>
			
			<div id="right-wrapper">
			
				<div id="motifs">
					<h2>Motifs</h2>	
					<ol id="resultsList">
					</ol>
				</div>
					
				<div id="instances">
					<div id="hidden-helper"></div>
					<h2 >Instance</h2>
					<div id="tabs">
						<ul>
							<li><a href="#tabs-0">Summary</a></li>
							<li><a href="#tabs-1">Instance</a></li>
							<li><a href="#tabs-2">Node Data</a></li>
							<li><a href="#tabs-3">Edge Data</a></li>
						</ul>
						<div id="tabs-0">Fuzzzy muzzzy!</div>
						<div id="tabs-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
						<div id="tabs-2">Phasellus mattis tincidunt nibh. Cras orci urna, blandit id, pretium vel, aliquet ornare, felis. Maecenas scelerisque sem non nisl. Fusce sed lorem in enim dictum bibendum.</div>
						<div id="tabs-3">Nam dui erat, auctor a, dignissim quis, sollicitudin eu, felis. Pellentesque nisi urna, interdum eget, sagittis et, consequat vestibulum, lacus. Mauris porttitor ullamcorper augue.</div>
					</div>
				</div>
						
			</div>
			
		</div>
			
	</div>
</body>
</html>

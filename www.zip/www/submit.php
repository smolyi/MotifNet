<html>
<head>
	<link type="text/css" href="css/smoothness/jquery-ui-1.8.20.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="js/jQuery/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="js/jQuery/jquery-ui-1.8.20.custom.min.js"></script>
	<script type="text/javascript" src="js/submit.js"></script>
	<style>
	.submissionMainForm {
		padding:1%;
	}
	#outputSubmissionForm{display:none;}
	#submitJobForm{display:block;}
	.submitOnly{display:block;}
	.graphOnly{display:none;}
	</style>
	
</head>
<body onload="formMode();">
Mode:
<input name="mode" type="radio" value="submit" onchange="formMode();" checked />Submit a job
<input name="mode" type="radio" value="graph" onchange="formMode();" />Generate graph for FANMOD input
<input name="mode" type="radio" value="output" onchange="formMode();" />submit FANMOD output
<br><br>

<form id="submitJobForm" method="POST" class="submissionMainForm" enctype="multipart/form-data" >
	<h2 class="submitOnly">Submit a job:<br></h2> 
	<h2 class="graphOnly">Generate graph for FANMOD input:<br></h2>
	<br>
	<div class="submitOnly">Job name: <input id="job" name="job" type="text"  /> <br> </div>
	<div class="submitOnly">E-mail: <input id="email" name="email" type="text"  /> <br> </div>
	<br><br>
	Motifs size: 
	<select id="sizeOfMotif" name="sizeOfMotif" onchange="sizeChanged();">
		  <option value="3">3</option>
		  <option value="4">4</option>
		  <option value="5">5</option>
		  <option value="6">6</option>
		  <option value="7">7</option>
		  <option value="8">8</option>
	</select> <br>
	<div id="edgeFiles">Edges files: <br></div>
	<br>
	<br>
	<div id="nodeFiles">Nodes files: <br></div>
	<div class="submitOnly">
	<br>
	max pvalue: <input id="maxPvalue"  name="maxPvalue" type="text" value="0.05" /> <br>
	min instances: <input id="minOccurrences" name="minOccurrences" type="text" value="1" /> <br>
	min zscore: <input id="minZscore"  name="minZscore" type="text" value="0" /> <br>
	max dangling edges: <input id="maxDangling"  name="maxDangling" type="text" value="0" /> <br>
	only colored: <input id="onlyColored" name="onlyColored" type="checkbox" checked=true /> <br>
	</div>
	<input id="submitJobButton" class="submitOnly" type="button" onclick="submitJob();" style="width:100px;" value="Submit" />
	<input id="graphButton" class="graphOnly" type="button" onclick="generateGraph();" style="width:100px;" value="Generate" />
	<input type="reset" value="Reset" /><br>
</form>


<form id="outputSubmissionForm"  method="POST" class="submissionMainForm" enctype="multipart/form-data" >
	<h2 >Submit FANMOD output:<br></h2>
	<br>
	Job name: <input id="job" name="job" type="text"  /> <br>
	E-mail: <input id="email" name="email" type="text"  /> <br>
	Comments: <br>
	<textarea id="comments" name="comments" ></textarea>
	
	<hr>
	
	
	CSV file: <input id="csvFile" class="file" name="csvFile" type="file"  /><br>
	dump: <input id="dumpFile" name="dumpFile" type="file"  /><br>
	dict: <input id="nodesMappingFile" name="nodesMappingFile" type="file"  /><br>
	labelsDict: <input id="labelsMappingFile" name="labelsDict" type="file"  /><br>
	Network file(optional): <input id="networkFile" name="networkFile" type="file" /><br>
	
	<hr>
	
	max pvalue: <input id="maxPvalue" name="maxPvalue" type="text" value="0.05" /> <br>
	min instances: <input id="minOccurrences" name="minOccurrences" type="text" value="1" /> <br>
	min zscore: <input id="minZscore" name="minZscore" type="text" value="0" /> <br>
	max dangling edges: <input id="maxDangling" name="maxDangling" type="text" value="0" /> <br>
	only colored: <input id="onlyColored" name="onlyColored" type="checkbox" checked=true /> <br>
	
	<hr>
	<input id="submitJobButton" type="button" onclick="submitFandmodOutput();" style="width:100px;" value="Submit" />
	<input type="reset" value="Reset" /><br>
</form>
</body>
</html>
